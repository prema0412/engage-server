package com.company.engage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EngageApplication {

	public static void main(String[] args) {
		SpringApplication.run(EngageApplication.class, args);
	}

}
